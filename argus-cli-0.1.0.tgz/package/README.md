# Argus

Magento 2 frontend GraphQL debug CLI. The hundred-eyed watcher.

A terminal-resident diagnostic console for Magento 2 frontend GraphQL — interactive TUI plus a non-interactive `blitz` subcommand. Built on Ink 5, undici, zero filesystem persistence of secrets, and an outbound allow-list.

## Install

```sh
npm install -g argus-cli
```

Requires Node.js ≥ 20.

Binaries: `argus` (long form) and `ag` (short alias).

## Quick start

```sh
argus                                       # interactive TUI
argus --endpoint https://shop.example/graphql
ARGUS_ADMIN_KEY=xxx argus blitz user@example.com default
```

## Configuration

Optional `~/.argusrc.json`:

```json
{
  "endpoint": "https://shop.example.com/graphql",
  "defaultStoreCode": "default",
  "timeoutMs": 10000
}
```

Resolution cascade for the endpoint: `--endpoint` flag → `ARGUS_ENDPOINT` env → config file → interactive prompt.

The config schema is strict — unknown keys (like tokens or admin keys) are rejected on load.

## Modes

### Blitzkrieg
Surface a customer's full frontend commerce state in four keystrokes after admin auth.
- prompts: email + store code
- acquires customer token via `generateCustomerTokenAsAdmin`
- fans out three parallel queries: customer + addresses, cart summary, cart detail
- renders three panels with badges, tables, totals
- footer actions: `r` refresh · `c` copy cart-id · `j` dump json · `b` back · `q` quit

### Reserved (planned)
Cart Forge · Schema Diff · Mutation Lab · Cache Inspector · Order Probe · Wishlist Probe · Catalog Probe.

## Non-interactive

```sh
ARGUS_ADMIN_KEY=… argus blitz <email> <store-code>
```

- admin key is read from env only — refused on argv
- emits a single sanitised JSON object on stdout
- exit codes: `0` full success · `2` partial · `3` token failure · `4` admin auth failure · `1` other

## Security

1. Admin key entered via masked input; never logged, written, or re-rendered.
2. Customer token is mode-scoped and cleared on mode exit.
3. All snapshot dumps run through a redactor — admin keys, customer tokens, and any field matching `token | authorization | password | secret | api_key | bearer` are replaced with `«redacted»`.
4. Outbound network egress is restricted to the configured endpoint host via an undici dispatcher allow-list — verified by unit test.
5. No telemetry, no analytics, no update checks, no remote schema fetch.
6. On `SIGINT` / `SIGTERM` / clean exit, secret references are zeroized.

## Magento prerequisites

`generateCustomerTokenAsAdmin` is a B2B / EE-era mutation; if your storefront does not expose it natively, install the matching module before relying on the Blitzkrieg flow.

## Development

```sh
npm install
npm run dev          # tsup watch
npm run typecheck
npm test
npm run build
node dist/cli.js
```

Layout follows the PRD — operations under `src/graphql/operations/` are the only places GraphQL strings exist; everything else imports them.

## License

MIT.
